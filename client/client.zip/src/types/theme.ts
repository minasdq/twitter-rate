// eslint-disable-next-line import/prefer-default-export
export enum ThemeMode {
  LIGHT = 'LIGHT',
  DARK = 'DARK',
}
